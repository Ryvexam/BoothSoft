# Warm Studio theme

Modify `config.toml` and `assets/*.png` only. Do not store secrets.
